public class MahasiswaBaru extends Mahasiswa {
    private String asalSekolah;

    public MahasiswaBaru(String nim, String nama, int semester, int[] nilai, String asalSekolah) {
        super(nim, nama, semester, nilai);
        this.asalSekolah = asalSekolah;
    }

    public boolean ikutOspek() {
        return true;
    }

    public void infoMahasiswa() {
        super.infoMahasiswa();
        System.out.println("Asal Sekolah: " + asalSekolah);
    }
}