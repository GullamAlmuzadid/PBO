public class MahasiswaAktif extends Mahasiswa {
    public MahasiswaAktif(String nim, String nama, int semester, int[] nilai) {
        super(nim, nama, semester, nilai);
    }

    
}