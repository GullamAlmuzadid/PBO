public class MahasiswaTransfer extends Mahasiswa {
    private String asalUniversitas;

    public MahasiswaTransfer(String nim, String nama, int semester, int[] nilai, String asalUniversitas) {
        super(nim, nama, semester, nilai);
        this.asalUniversitas = asalUniversitas;
    }

    public boolean ikutOspek() {
        return true;
    }

    public void infoMahasiswa() {
        super.infoMahasiswa();
        System.out.println("Asal Universitas: " + asalUniversitas);
    }
}