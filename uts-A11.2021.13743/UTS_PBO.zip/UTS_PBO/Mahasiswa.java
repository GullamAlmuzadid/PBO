

public class Mahasiswa {
    private String nim;
    private String nama;
    private int semester;
    private int[] nilai;

    public Mahasiswa(String nim, String nama, int semester, int[] nilai) {
        this.nim = nim;
        this.nama = nama;
        this.semester = semester;
        this.nilai = nilai;
    }

    public float hitungRataNilai() {
        int total = 0;
        for (int i = 0; i < nilai.length; i++) {
            total += nilai[i];
        }
        return (float) total / nilai.length;
    }

    public void infoMahasiswa() {
        System.out.println("NIM: " + nim);
        System.out.println("Nama: " + nama);
        System.out.println("Semester: " + semester);
        System.out.println("Nilai: " + nilai);
    }

    public void infoKrsMahasiswa() {
        System.out.println("KRS Mahasiswa:");
    }
    
}
