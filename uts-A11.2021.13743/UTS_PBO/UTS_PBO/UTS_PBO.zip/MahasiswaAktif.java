public class MahasiswaAktif extends Mahasiswa {

    public MahasiswaAktif(String nim, String nama, int semester, int usia, String[] krs, int[] nilai) {
        super(nim, nama, semester, usia, krs, nilai);
    }

    @Override
    public void infoMahasiswa() {
        super.infoMahasiswa();
    }
}
